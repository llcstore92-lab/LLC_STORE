#ifndef REPUBLIC_CHEAT_IMPORTANT_IMPORT_H
#define REPUBLIC_CHEAT_IMPORTANT_IMPORT_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cerrno>
#include <sys/un.h>
#include <cstring>
#include <string>
#include <cmath>
#include "struct.h"


bool isPlayerBox = true;
bool isPlayerLine = true;
bool isPlayerDist = true;
bool isPlayerHealth = true;
bool isPlayerName = true;
bool isPlayerHead = true;
bool isPlayer360Alert = true;
bool isSkeletonBones = true;
bool isGrenadeWarning = true;
bool isPlayerWeapon= true;
bool isPlayerWeaponText = true;
bool isVisibility = true;

Vec2 pushToScreenBorder(Vec2 Pos, Vec2 screen, int offset) {
    int x = (int)Pos.x;
    int y = (int)Pos.y;
    if (Pos.y < 0) {
        // top
        y = -offset;
    }
    if (Pos.x > screen.x) {
        // right
        x = (int)screen.x + offset;
    }
    if (Pos.y > screen.y) {
        // bottom
        y = (int)screen.y + offset;
    }
    if (Pos.x < 0) {
        // left
        x = -offset;
    }
    return Vec2(x, y);
}

bool isOutsideSafeZone(Vec2 pos, Vec2 screen) {
    if (pos.y < 0) {
        return true;
    }
    if (pos.x > screen.x) {
        return true;
    }
    if (pos.y > screen.y) {
        return true;
    }
    return pos.x < 0;
}

#endif //REPUBLIC_CHEAT_IMPORTANT_IMPORT_H
