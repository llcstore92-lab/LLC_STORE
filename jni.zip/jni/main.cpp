#include <Includes.h>
#include <pthread.h>
#include <jni.h>
#include <string>
#include "ESP.h"
#include "Hacks.h"
#include "StrEnc.h"
#include "HackShooter.h"
#include "json.hpp"
#include "Tools.h"
#include "obfuscate.h"
#include "bypass.h"  // <-- Tambahkan ini

ESP espOverlay;
int type=1,utype=2;

using json = nlohmann::ordered_json;

int expiredDate;

bool DaddyXerr0r = false;

// ========== PROTECTED GLOBALS ==========
std::string credit, g_Licence;
std::string modname;
std::string token;

// Format key yang diterima
const std::string KEY_PREFIX = "IIc";
const std::string KEY_SUFFIX = "ia";

// ========== PROTECTED FUNCTIONS ==========
// Fungsi untuk mengekstrak key dari format (dengan proteksi)
std::string extractKey(const std::string& input) {
    BYPASS_DELAY(10);  // Tambahkan delay acak
    
    if (input.length() < KEY_PREFIX.length() + KEY_SUFFIX.length() + 1) {
        return "";
    }
    
    if (input.find(KEY_PREFIX) != 0) {
        return "";
    }
    
    size_t suffixPos = input.length() - KEY_SUFFIX.length();
    std::string actualSuffix = input.substr(suffixPos);
    if (actualSuffix != KEY_SUFFIX) {
        return "";
    }
    
    size_t keyStart = KEY_PREFIX.length();
    size_t keyLength = input.length() - KEY_PREFIX.length() - KEY_SUFFIX.length();
    
    if (keyLength <= 0) {
        return "";
    }
    
    std::string extractedKey = input.substr(keyStart, keyLength);
    
    // Obfuscate key untuk proteksi tambahan
    return BYPASS_OBFUSCATE(extractedKey);
}

// Fungsi untuk validasi format key (dengan proteksi)
bool isValidKeyFormat(const std::string& input) {
    BYPASS_DELAY(5);
    
    if (input.length() < KEY_PREFIX.length() + KEY_SUFFIX.length() + 1) {
        return false;
    }
    
    if (input.substr(0, KEY_PREFIX.length()) != KEY_PREFIX) {
        return false;
    }
    
    size_t suffixPos = input.length() - KEY_SUFFIX.length();
    if (input.substr(suffixPos) != KEY_SUFFIX) {
        return false;
    }
    
    size_t keyLength = input.length() - KEY_PREFIX.length() - KEY_SUFFIX.length();
    if (keyLength <= 0) {
        return false;
    }
    
    return true;
}

// ========== PROTECTED NATIVE CHECK ==========
jstring native_Check(JNIEnv *env, jclass clazz, jobject mContext, jstring mUserKey) {
    // ========== BYPASS PROTECTION LAYER 1 ==========
    BYPASS_INIT();
    
    // Cek environment aman
    if (!BYPASS_IS_SAFE()) {
        return env->NewStringUTF("virtual_device_detected");
    }
    
    // Tambahkan delay acak
    BYPASS_DELAY(100);
    
    auto userKey = env->GetStringUTFChars(mUserKey, 0);
    
    // Ekstrak key dari format
    std::string originalKey = userKey;
    std::string extractedKey = extractKey(originalKey);
    
    // Deobfuscate key
    extractedKey = BYPASS_DEOBFUSCATE(extractedKey);
    
    // Jika key tidak valid formatnya, langsung return error
    if (extractedKey.empty()) {
        env->ReleaseStringUTFChars(mUserKey, userKey);
        return env->NewStringUTF("Invalid Key");
    }
    
    // ========== BYPASS PROTECTION LAYER 2 ==========
    // Gunakan ProtectedJNI untuk device info
    std::string hwid = extractedKey;  
    hwid += ProtectedJNI::GetAndroidID(env, mContext);
    hwid += ProtectedJNI::GetDeviceModel(env);  
    hwid += ProtectedJNI::GetDeviceBrand(env);  
    
    // Obfuscate HWID sebelum diproses lebih lanjut
    std::string obfuscated_hwid = BYPASS_OBFUSCATE(hwid);
    
    // Generate UUID menggunakan HWID yang sudah diobfuscate
    std::string UUID = GetUUID(env, obfuscated_hwid.c_str());  

    std::string errMsg;  

    struct MemoryStruct chunk{};  
    chunk.memory = (char *) malloc(1);  
    chunk.size = 0;  

    CURL *curl;  
    CURLcode res;  
    curl = curl_easy_init();  
    if (curl) {  
        // ========== BYPASS PROTECTION LAYER 3 ==========
        // Tambahkan delay sebelum request network
        BYPASS_DELAY(200);
        
        std::string url = OBFUSCATE("https://free.kuropanel.me/public/connect");  
        
        // ========== BYPASS PROTECTION LAYER 4 ==========
        // Obfuscate data sebelum dikirim
        std::string obfuscated_key = BYPASS_OBFUSCATE(extractedKey);
        std::string obfuscated_uuid = BYPASS_OBFUSCATE(UUID);
        
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "POST");  
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());  
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);  
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, "https");  
        
        struct curl_slist *headers = NULL;  
        headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");  
        
        // ========== BYPASS PROTECTION LAYER 5 ==========
        // Tambahkan header acak untuk menghindari fingerprinting
        char random_header[64];
        snprintf(random_header, sizeof(random_header), "X-Device-Signature: %08x", rand() ^ time(NULL));
        headers = curl_slist_append(headers, random_header);
        
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);  

        char data[4096];  
        sprintf(data, "game=PUBG&user_key=%s&serial=%s", 
                BYPASS_DEOBFUSCATE(obfuscated_key).c_str(), 
                BYPASS_DEOBFUSCATE(obfuscated_uuid).c_str());  
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);  

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);  
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);  

        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);  
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);  
        
        // ========== BYPASS PROTECTION LAYER 6 ==========
        // Tambahkan timeout acak
        int random_timeout = 10 + (rand() % 20);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, random_timeout);

        res = curl_easy_perform(curl);  
        if (res == CURLE_OK) {  
            try {  
                json result = json::parse(chunk.memory);  
                if (result["status"] == true) {  
                    std::string token = result["data"]["token"].get<std::string>();  
                    expiredDate = result["data"]["rng"].get<time_t>();  
                    
                    if (expiredDate + 30 > time(0)) {  
                        std::string auth = "PUBG";  
                        auth += "-";  
                        auth += extractedKey;  
                        auth += "-";  
                        auth += UUID;  
                        auth += "-";  
                        
                        std::string license = OBFUSCATE("Vm8LD3eC0d3rSaADCPVPVTaNhASuF19E");  
                        auth += license.c_str();  
                        
                        std::string outputAuth = Tools::CalcMD5(auth);  
                        DaddyXerr0r = true;  
                        
                        if (DaddyXerr0r) {  
                            pthread_t t;  
                            // Protection thread bisa ditambahkan di sini
                        }  
                        g_Licence = result["data"]["EXP"].get<std::string>();  
                    }  
                } else {  
                    errMsg = result["reason"].get<std::string>();  
                }  
            } catch (json::exception &e) {  
                // ========== BYPASS PROTECTION LAYER 7 ==========
                // Error handling dengan obfuscation
                errMsg = "{";  
                errMsg += BYPASS_OBFUSCATE(e.what());
                errMsg += "}\n{";  
                errMsg += BYPASS_OBFUSCATE(chunk.memory);
                errMsg += "}";  
            }  
        } else {  
            errMsg = curl_easy_strerror(res);  
        }  
    }  
    curl_easy_cleanup(curl);  
    
    // ========== BYPASS PROTECTION LAYER 8 ==========
    // Secure memory cleanup
    if (chunk.memory) {
        memset(chunk.memory, 0, chunk.size); // Clear memory
        free(chunk.memory);
        chunk.memory = nullptr;
    }
    
    env->ReleaseStringUTFChars(mUserKey, userKey);
    
    // ========== BYPASS PROTECTION LAYER 9 ==========
    // Return dengan obfuscation jika error
    if (!DaddyXerr0r) {
        std::string safe_err_msg = BYPASS_OBFUSCATE(errMsg);
        return env->NewStringUTF(safe_err_msg.c_str());
    }
    
    return env->NewStringUTF("OK");
}

// ========== JNI FUNCTIONS DENGAN BYPASS ==========

/* Other Activity */
extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_SplashActivity_LinkPhp(JNIEnv *env, jclass clazz) {
    BYPASS_DELAY(20);
    return env->NewStringUTF(OBFUSCATE("https://my.deadlyofcheat.my.id/ApkJsonDeteksi/check.php"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_LoginActivity_GetKey(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(20);
    return env->NewStringUTF(OBFUSCATE("https://t.me/llc_store"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_MainActivity_urldata(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(20);
    return env->NewStringUTF(OBFUSCATE("https://github.com/rayansyed77/SetupX/releases/download/kentos/assets.zip"));
}

extern "C"
JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_Toggle_AimKontol(JNIEnv *env, jobject thiz, jint setting_code,
                                            jboolean value) {
    BYPASS_DELAY(5);
    switch((int)setting_code){
        case 13:
            if(value != 0)
                options.aimBullet=0;
            else
                options.aimBullet=-1;
            break;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_Range(JNIEnv *env, jobject obj, jint range) {
    BYPASS_DELAY(5);
    options.aimingRange=1+range;
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_distances(JNIEnv *env, jobject obj, jint distances) {
    BYPASS_DELAY(5);
    options.aimingDist=distances;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_recoil(JNIEnv *env, jobject thiz, jint recoil) {
    BYPASS_DELAY(5);
    // options.Recoil = recoil;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_Bulletspeed(JNIEnv *env, jobject thiz, jint bulletspeed) {
    BYPASS_DELAY(5);
    // options.bulletSpeed = bulletspeed;
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_Target(JNIEnv *env, jobject obj, jint target) {
    BYPASS_DELAY(5);
    options.aimbotmode=target;
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_AimWhen(JNIEnv *env, jobject obj, jint state) {
    BYPASS_DELAY(5);
    options.aimingState=state;
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_AimBy(JNIEnv *env, jobject obj, jint aimby) {
    BYPASS_DELAY(5);
    options.priority=aimby;
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_Overlay_DrawOn(JNIEnv *env, jclass cls, jobject espView, jobject canvas) {
    BYPASS_DELAY(10);
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_Overlay_Close(JNIEnv *env, jobject obj) {
    BYPASS_DELAY(10);
    Close();
    options.aimBullet=-1;
}

extern "C" JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_SettingValue(JNIEnv *env, jobject obj, jint code,jboolean jboolean1) {
    BYPASS_DELAY(5);
    switch((int)code){
        case 2:
            isPlayerLine = jboolean1;  break;
        case 3:
            isPlayerBox = jboolean1;   break;
        case 4:
            isSkeletonBones = jboolean1;  break;
        case 5:
            isPlayerDist = jboolean1;  break;
        case 6:
            isPlayerHealth = jboolean1;  break;
        case 7:
            isPlayerName = jboolean1;  break;
        case 8:
            isPlayerHead = jboolean1;  break;
        case 9:
            isPlayer360Alert = jboolean1;  break;
        case 10:
            isPlayerWeapon=jboolean1;  break;
        case 11:
            isGrenadeWarning=jboolean1; break;
        case 12:
            isVisibility=jboolean1; break;
        case 20:
            isPlayerWeaponText = jboolean1;
            break;
        case 13:
            if(jboolean1 != 0)
                options.aimBullet=0;
            else
                options.aimBullet=-1;
            break;
        case 14:
            options.pour=jboolean1;
            break;
        case 15:
            options.tracingStatus=jboolean1;
            break;
        case 28:
            options.ignoreBot=jboolean1;
            break;
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_deadly_OverlayESP_FloatLogo_SettingMemory(JNIEnv *env, jobject thiz, jint setting_code,
                                                  jboolean value) {
    BYPASS_DELAY(5);
    switch((int)setting_code){
        case 1:
            otherFeature.WideView = value;
            break;
        case 2:
            otherFeature.SmallCrosshair = value;
            break;
        case 3:
            // otherFeature.Aimlock = value;
            break;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_deadly_OverlayESP_Overlay_getReady(JNIEnv *env, jclass cls, int typeofgame) {
    BYPASS_DELAY(50);
    
    // Cek environment sebelum melakukan operasi sensitif
    if (!BYPASS_IS_SAFE()) {
        return false;
    }
    
    int sockCheck=1;

    if (!Create()) {  
        perror("Creation failed");  
        return false;  
    }  
    setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&sockCheck, sizeof(int));  
    if (!Bind()) {  
        perror("Bind failed");  
        return false;  
    }  

    if (!Listen()) {  
        perror("Listen failed");  
        return false;  
    }  
    if (Accept()) {  
        return true;  
    }
    return false;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_downloader_DownloadZip_pw(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("1212"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_downloader_DownloadZip_ewrhhj(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("remover.sh"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_MainActivity_URLLOADER(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("https://github.com/XNoRerCodes/FuckYouShitC-P/raw/main/Saved.zip"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_LoaderActivity_SOCKINDI64(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("https://github.com/XNoRerCodes/FuckYouShitC-P/raw/main/3.zip"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_LoaderActivity_SOCKALL64(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("https://github.com/XNoRerCodes/FuckYouShitC-P/raw/main/1.zip"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_LoaderActivity_SOCKALL32(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("https://github.com/XNoRerCodes/FuckYouShitC-P/raw/main/2.zip"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_downloader_Downtwo_ewrhhj(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("remover.sh"));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_downloader_Downtwo_pw(JNIEnv *env, jobject thiz) {
    BYPASS_DELAY(10);
    return env->NewStringUTF(OBFUSCATE("1212"));
}

// ========== JNI REGISTRATION ==========
int Register1(JNIEnv *env) {
    JNINativeMethod methods[] = {
        {"suckmydick", "(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;", (void *) native_Check}
    };

    jclass clazz = env->FindClass("com/deadly/activity/LoginActivity");  
    if (!clazz)  
        return -1;  

    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)  
        return -1;  

    return 0;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    
    // Inisialisasi bypass system
    BYPASS_INIT();
    
    if (Register1(env) != 0)
        return -1;
    return JNI_VERSION_1_6;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_fragment_Fragment_1home_EXP(JNIEnv *env, jclass clazz) {
    BYPASS_DELAY(10);
    
    // Obfuscate license sebelum ditampilkan
    if (!g_Licence.empty()) {
        std::string obfuscated = BYPASS_OBFUSCATE(g_Licence);
        return env->NewStringUTF(obfuscated.c_str());
    }
    
    return env->NewStringUTF("");
}

// ========== INITIALIZATION FUNCTION ==========
extern "C"
JNIEXPORT void JNICALL
Java_com_deadly_activity_MainActivity_initProtection(JNIEnv *env, jobject thiz) {
    // Initialize bypass system
    BYPASS_INIT();
    
    // Check if environment is safe
    if (!BYPASS_IS_SAFE()) {
        // Jika environment tidak aman, tambahkan delay ekstra
        BYPASS_DELAY(1000);
    }
}

// ========== ENVIRONMENT CHECK ==========
extern "C"
JNIEXPORT jstring JNICALL
Java_com_deadly_activity_MainActivity_checkEnvironment(JNIEnv *env, jobject thiz) {
    BYPASS_INIT();
    
    if (BypassGuard::is_restricted_environment()) {
        return env->NewStringUTF("restricted_environment");
    }
    
    return env->NewStringUTF("safe_environment");
}