#ifndef REPUBLIC_CHEAT_IMPORTANT_HACKS_H
#define REPUBLIC_CHEAT_IMPORTANT_HACKS_H

#include "socket.h"
#include "ColorRandom.h"

Request request;
Response response;


float x,y;
char extra[30];
int botCount, playerCount;

Color clrHealth,clrLine,clrSkeleton,clrHead,clrAlert,clrbox,clrfilledbox,headclr,skeclr,bxclr,bxfillclr,clrPov,clrPv,clrln,clrID;

Options options{1, -1, -1, 3, false, false, 1, false, 200, 200, 200, 19, 19, -1, false};
OtherFeature otherFeature{false, false};


//TODO : VISIBILITY CHECK
bool colorPosCenter(float sWidth, float smMx, float sHeight, float posT, float eWidth, float emMx, float eHeight, float posB) {
    if (sWidth >= smMx && sHeight >= posT && eWidth <= emMx && eHeight <= posB) {
        return true;
    }
    return false;
} //END FUNCTION 1

//TODO : FPS DATA
uint64_t GetTickCount() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

class Interval {
private:
    int initial_;

public:
    inline Interval() : initial_(GetTickCount()) {}

    virtual ~Interval() {}

    inline unsigned int value() const {
        return GetTickCount() - initial_;
    }
};

class FPS {
protected:
    int32_t m_fps;
    int32_t m_fpscount;
    Interval m_fpsinterval;

public:
    FPS() : m_fps(0), m_fpscount(0) {}

    void Update() {
        m_fpscount++;
        if (m_fpsinterval.value() > 1000) {
            m_fps = m_fpscount;
            m_fpscount = 0;
            m_fpsinterval = Interval();
        }
    }

    int32_t get() const {
        return m_fps;
    }
};

FPS m_fps;


void DrawESP(ESP esp, int screenWidth, int screenHeight) {

    m_fps.Update();
    char *tsr = "FPS : ";
    std::string Str = std::string(tsr);
    Str += std::to_string((int) m_fps.get());
    esp.DrawTextBold(Color(255,255,255), Str.c_str(), Vec2(210, 80), 26);
    esp.DrawTextMode(Color(255, 255, 255), "",Vec2(screenWidth / 5 , screenHeight / 1.05),screenHeight / 45);

     if (true) {
         if (botCount + playerCount > 0)
         {
             sprintf(extra, "%d", botCount + playerCount);
         }
         else if (response.InLobby)
         {
             sprintf(extra, "LOBBY");
         }
         else
         {
             sprintf(extra, "CLEAR");
         }


         if (botCount + playerCount > 0)
         {
             esp.DrawFilledRect(Color(255, 0, 0, 40),
                                Vec2(screenWidth / 2 - screenHeight / 12,
                                     screenHeight / 19),
                                Vec2(screenWidth / 2 + screenHeight / 12,
                                     screenHeight / 10));
             esp.DrawRect(Color(255, 0, 0, 255), 3,
                          Vec2(screenWidth / 2 - screenHeight / 12,
                               screenHeight / 19),
                          Vec2(screenWidth / 2 + screenHeight / 12,
                               screenHeight / 10));
             esp.DrawText(Color(255, 255, 255), extra,
                          Vec2(screenWidth / 2,
                               screenHeight / 11.5), screenHeight / 32);

         }
         else
         {
             esp.DrawFilledRect(Color(0, 255, 0, 50),    // green
                                Vec2(screenWidth / 2 - screenHeight / 12,
                                     screenHeight / 19),
                                Vec2(screenWidth / 2 + screenHeight / 12,
                                     screenHeight / 10));
             esp.DrawRect(Color(0, 255, 0, 255), 3,
                          Vec2(screenWidth / 2 - screenHeight / 12,
                               screenHeight / 19),
                          Vec2(screenWidth / 2 + screenHeight / 12,
                               screenHeight / 10));


             esp.DrawText(Color(255, 255, 255), extra,
                          Vec2(screenWidth / 2,
                               screenHeight / 11.5), screenHeight / 32);


         }
     }

/*
    if (!bValid && !lolo)
        return;
    if (!g_Token.empty()) {
        if (!g_Auth.empty()) {
            if (g_Token == g_Auth) {*/
                botCount = 0;
                playerCount = 0;
                request.ScreenHeight = screenHeight;
                request.ScreenWidth = screenWidth;
                request.Mode = InitMode;
                request.options = options; //for aimbot
                request.otherFeature = otherFeature;
                send((void *) &request, sizeof(request));
                receive((void *) &response);
                if (response.Success) {
                    float textsize = screenHeight / 50;
                    for (int i = 0; i < response.PlayerCount; i++) {
                        // ========= TAMBAHKAN FILTER KEMATIAN DI SINI =========
                        if (response.Players[i].Health <= 0.0f) {
                            continue; // Skip player yang sudah mati
                        }
                        // ========= FILTER SELESAI =========
                        
                        x = response.Players[i].HeadLocation.x;
                        y = response.Players[i].HeadLocation.y;
                        if (response.Players[i].isBot) {
                            botCount++;
                            clrLine = Color(255, 255, 255, 255);
                            clrSkeleton = Color(255, 255, 255, 255);
                            clrHead = Color(255, 255, 255, 180);
                            clrAlert = Color(255, 255, 255, 80);
                            clrbox = Color(255, 255, 255, 255);
                            clrfilledbox = Color(255, 255, 255, 35);
                        } else {
                            playerCount++;
                            clrLine = Color(255, 0, 0, 255);
                            clrSkeleton = Color(255, 0, 0, 255);
                            clrHead = Color(255, 0, 0, 180);
                            clrAlert = Color(38, 105, 255);
                            clrbox = Color(255, 0, 0, 255);
                            clrfilledbox = Color(255, 0, 0, 35);
                        }


                        float magic_number = (response.Players[i].Distance * response.fov);
                        float namewidht = (screenWidth / 6) / magic_number;
                        float mx = (screenWidth / 4) / magic_number;
                        float my = (screenWidth / 1.38) / magic_number;
                        float top = y - my + (screenWidth / 1.7) / magic_number;
                        float bottom = response.Players[i].Bone.lAn.y + my -
                                       (screenWidth / 1.7) / magic_number;
                        Vec2 screen(screenWidth, screenHeight);
                        Color _colorByDistance = colorByDistance((int)response.Players[i].Distance, 255);
                        Color _ColorTeamById = TeamById((int)response.Players[i].TeamID, 150);
                        Color _ColorTeamById2 = TeamById((int)response.Players[i].TeamID, 255);
                        Color clrID = _clrID((int)response.Players[i].TeamID, 150);
                        Color clrID2 = _clrID2((int)response.Players[i].TeamID, 255);
                        float mScale = screenHeight / (float) 1080;
                        float textsize = screenHeight / 50;

                        //TODO : VISCHECK 2
                        bool playerInCenter = colorPosCenter(screenWidth / 2, x - mx,
                                                             screenHeight / 2, top, screenWidth / 2,
                                                             x + mx, screenHeight / 2, bottom);

                        //NEW FUNCTION
                        if (isVisibility) {
                            headclr = playerInCenter ? Color::Green() : clrHead;
                            skeclr = playerInCenter ? Color::Green() : clrSkeleton;
                            bxclr = playerInCenter ? Color::Green() : clrbox;
                            bxfillclr = playerInCenter ? Color::Green2() : clrfilledbox;
                            clrln = playerInCenter ? Color::Green() : clrLine;
                        } else {
                            headclr = clrHead;
                            skeclr = clrSkeleton;
                            bxclr = clrbox;
                            bxfillclr = clrfilledbox;
                            clrln = clrLine;
                        } //END


                        //Start Skeleton
                        if (response.Players[i].HeadLocation.z != 1) {
                            // On Screen
                            if (x > -50 && x < screenWidth + 50) {

                                if (isSkeletonBones && response.Players[i].Bone.isBone) {  //Skelton
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.neck.x,
                                                         response.Players[i].Bone.neck.y),
                                                    Vec2(response.Players[i].Bone.cheast.x,
                                                         response.Players[i].Bone.cheast.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.cheast.x,
                                                         response.Players[i].Bone.cheast.y),
                                                    Vec2(response.Players[i].Bone.pelvis.x,
                                                         response.Players[i].Bone.pelvis.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.neck.x,
                                                         response.Players[i].Bone.neck.y),
                                                    Vec2(response.Players[i].Bone.lSh.x,
                                                         response.Players[i].Bone.lSh.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.neck.x,
                                                         response.Players[i].Bone.neck.y),
                                                    Vec2(response.Players[i].Bone.rSh.x,
                                                         response.Players[i].Bone.rSh.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.lSh.x,
                                                         response.Players[i].Bone.lSh.y),
                                                    Vec2(response.Players[i].Bone.lElb.x,
                                                         response.Players[i].Bone.lElb.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.rSh.x,
                                                         response.Players[i].Bone.rSh.y),
                                                    Vec2(response.Players[i].Bone.rElb.x,
                                                         response.Players[i].Bone.rElb.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.lElb.x,
                                                         response.Players[i].Bone.lElb.y),
                                                    Vec2(response.Players[i].Bone.lWr.x,
                                                         response.Players[i].Bone.lWr.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.rElb.x,
                                                         response.Players[i].Bone.rElb.y),
                                                    Vec2(response.Players[i].Bone.rWr.x,
                                                         response.Players[i].Bone.rWr.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.pelvis.x,
                                                         response.Players[i].Bone.pelvis.y),
                                                    Vec2(response.Players[i].Bone.lTh.x,
                                                         response.Players[i].Bone.lTh.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.pelvis.x,
                                                         response.Players[i].Bone.pelvis.y),
                                                    Vec2(response.Players[i].Bone.rTh.x,
                                                         response.Players[i].Bone.rTh.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.lTh.x,
                                                         response.Players[i].Bone.lTh.y),
                                                    Vec2(response.Players[i].Bone.lKn.x,
                                                         response.Players[i].Bone.lKn.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.rTh.x,
                                                         response.Players[i].Bone.rTh.y),
                                                    Vec2(response.Players[i].Bone.rKn.x,
                                                         response.Players[i].Bone.rKn.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.lKn.x,
                                                         response.Players[i].Bone.lKn.y),
                                                    Vec2(response.Players[i].Bone.lAn.x,
                                                         response.Players[i].Bone.lAn.y));
                                    esp.DrawSkelton(skeclr, 1.5,
                                                    Vec2(response.Players[i].Bone.rKn.x,
                                                         response.Players[i].Bone.rKn.y),
                                                    Vec2(response.Players[i].Bone.rAn.x,
                                                         response.Players[i].Bone.rAn.y));
                                }

                                // Player Box
                                if (isPlayerBox) {
                                    esp.DrawRect1(clrSkeleton, 1,
                                                  Vec2(x - namewidht, top),
                                                  Vec2(x + namewidht, bottom));
                                }

                                //Player Health
                                if (isPlayerHealth) {
                                    float healthLength = screenWidth / 24;
                                    if (healthLength < mx)
                                        healthLength = mx;
                                    if (response.Players[i].Health < 25)
                                        clrHealth = Color(255, 0, 0,185);
                                    else if (response.Players[i].Health < 50)
                                        clrHealth = Color(255, 204, 0,185);
                                    else if (response.Players[i].Health < 75)
                                        clrHealth = Color(255, 255, 0, 185);
                                    else
                                        clrHealth = Color(58, 157, 95, 225);
                                    if (response.Players[i].Health == 0)
                                        esp.DrawText(Color(255, 0, 0), "Knock",
                                                     Vec2(x, top - screenHeight / 200), textsize),
                                                screenHeight / 27;
                                    else {
                                        esp.DrawFilledRect(clrHealth,
                                                           Vec2(x - healthLength, top - screenHeight / 30),
                                                           Vec2(x - healthLength +
                                                                (2 * healthLength) *
                                                                response.Players[i].Health /
                                                                100, top - screenHeight / 225));
                                        esp.DrawRect(Color(0, 0, 0), screenHeight / 640,
                                                     Vec2(x - healthLength, top - screenHeight / 30),
                                                     Vec2(x + healthLength, top - screenHeight / 255));
                                    }
                                }

                                //Player Head
                                if (isPlayerHead){
                                    esp.DrawFilledCircle(clrHead,Vec2(response.Players[i].HeadLocation.x,response.Players[i].HeadLocation.y),screenHeight /12 /magic_number);
                                }

                                //Player Names
                                if (isPlayerName && response.Players[i].isBot) {
                                    sprintf(extra, "Bot");
                                    esp.DrawText(Color(255, 255, 255), extra,
                                                 Vec2(x, top - 12),
                                                 textsize);
                                } else if (isPlayerName) {
                                    esp.DrawName(Color().White(),
                                                 response.Players[i].PlayerNameByte,
                                                 response.Players[i].TeamID,
                                                 Vec2(response.Players[i].HeadLocation.x,
                                                      top - 12),
                                                 textsize);
                                }

                                if (isPlayerDist) {
                                    sprintf(extra, "%0.0f M", response.Players[i].Distance);
                                    esp.DrawText(Color(247, 175, 63,255), extra,
                                                 Vec2(x, bottom + screenHeight / 45),
                                                 textsize);
                                }
                                // weapon text only
                                if (isPlayerWeaponText && response.Players[i].Weapon.isWeapon) {
                                    /*esp.DrawWeapon(Color(247, 175, 63), response.Players[i].Weapon.id,
                                                   response.Players[i].Weapon.ammo,response.Players[i].Weapon.ammo,
                                                   Vec2(x, top - 65), 20.0f);*/
                                    esp.DrawWeapon(Color(247, 175, 63,255), response.Players[i].Weapon.id,  response.Players[i].Weapon.ammo,response.Players[i].Weapon.ammo,
                                                   Vec2(x - 45, top - 45), textsize);
                                }

                                // weapon  icon
                                if (isPlayerWeapon && response.Players[i].Weapon.isWeapon) {
                                    esp.DrawWeaponIcon(response.Players[i].Weapon.id,
                                                       Vec2(x - screenWidth / 42,
                                                            top - screenHeight / 15));
                                }
                            }
                        }

                        // Player Alert 360
                        if (response.Players[i].HeadLocation.z == 1.0f)
                        {
                            // ========= TAMBAHKAN FILTER KEMATIAN DI SINI =========
                            if (response.Players[i].Health <= 0.0f) {
                                continue; // Skip player yang sudah mati
                            }
                            // ========= FILTER SELESAI =========
                            
                            if (!isPlayer360Alert)
                                continue;
                            if (x > screenWidth - screenWidth / 12)
                                x = screenWidth - screenWidth / 120;
                            else if (x < screenWidth / 120)
                                x = screenWidth / 12;
                            if (y < screenHeight / 1)
                            {


                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(screenWidth - x - 100,screenHeight - 48),
                                                 Vec2(screenWidth - x + 100,screenHeight + 2));
                                    esp.DrawFilledRect(Color(255, 0, 0, 150),
                                                       Vec2(screenWidth - x - 100,screenHeight - 48),
                                                       Vec2(screenWidth - x + 100,screenHeight + 2));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth - x, screenHeight - 20),textsize);

                            }


                            else
                            {


                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(screenWidth - x - 100, 48),
                                                 Vec2(screenWidth - x + 100, -2));
                                    esp.DrawFilledRect(Color(255, 0, 0, 150),
                                                       Vec2(screenWidth - x - 100, 48),
                                                       Vec2(screenWidth - x + 100, -2));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth - x, 25), textsize);
                            }


                        }
                        else if (x < -screenWidth / 10 || x > screenWidth + screenWidth / 10)
                        {
                            // ========= TAMBAHKAN FILTER KEMATIAN DI SINI =========
                            if (response.Players[i].Health <= 0.0f) {
                                continue; // Skip player yang sudah mati
                            }
                            // ========= FILTER SELESAI =========
                            
                            if (!isPlayer360Alert)
                                continue;
                            if (y > screenHeight - screenHeight / 12)
                                y = screenHeight - screenHeight / 120;
                            else if (y < screenHeight / 120)
                                y = screenHeight / 12;
                            if (x > screenWidth / 2)
                            {


                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(screenWidth - 88, y - 35),
                                                 Vec2(screenWidth + 2, y + 35));
                                    esp.DrawFilledRect(Color(255, 0, 0, 150),
                                                       Vec2(screenWidth - 88, y - 35),
                                                       Vec2(screenWidth + 2, y + 35));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth - screenWidth / 80, y + 10),
                                                 textsize);

                            }else{

                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(0 + 88, y - 35), Vec2(0 - 2, y + 35));
                                    esp.DrawFilledRect(Color(255, 0, 0, 150),
                                                       Vec2(0 + 88, y - 35), Vec2(0 - 2,
                                                                                  y + 35));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);

                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(screenWidth / 80, y + 10), textsize);
                            }

                        }       // depan
                        else if (y < -screenHeight / 10 || y > screenHeight + screenHeight / 10)
                        {
                            // ========= TAMBAHKAN FILTER KEMATIAN DI SINI =========
                            if (response.Players[i].Health <= 0.0f) {
                                continue; // Skip player yang sudah mati
                            }
                            // ========= FILTER SELESAI =========
                            
                            if ( !isPlayer360Alert)
                                continue;
                            if (x > screenWidth - screenWidth / 12)
                                x = screenWidth - screenWidth / 120;
                            else if (x < screenWidth / 120)
                                x = screenWidth / 12;
                            if (y > screenHeight / 2.5)
                            {


                                    esp.DrawRect(Color(255, 255, 255), 2,
                                                 Vec2(x - 100,screenHeight - 48), Vec2(x + 100, screenHeight + 2));
                                    esp.DrawFilledRect(Color(255, 0, 0, 150),
                                                       Vec2(x - 100, screenHeight - 48),
                                                       Vec2(x + 100, screenHeight + 2));
                                    sprintf(extra, "%0.0f m", response.Players[i].Distance);
                                    esp.DrawText(Color(255, 255, 255, 255), extra,
                                                 Vec2(x, screenHeight - 20), textsize);
                            }else{
                                if (isPlayer360Alert){
                                        esp.DrawRect(Color(255, 255, 255), 2,
                                                     Vec2(x - 100, 48), Vec2(x + 100, -2));
                                        esp.DrawFilledRect(Color(255, 0, 0, 150),
                                                           Vec2(x - 100, 48), Vec2(x + 100, -2));
                                        sprintf(extra, "%0.0f m", response.Players[i].Distance);

                                        esp.DrawText(Color(255, 255, 255, 255), extra,
                                                     Vec2(x, 25), textsize);
                                }
                            }
                        } else if (isPlayerLine) {
                            // ========= TAMBAHKAN FILTER KEMATIAN DI SINI =========
                            if (response.Players[i].Health <= 0.0f) {
                                continue; // Skip player yang sudah mati
                            }
                            // ========= FILTER SELESAI =========
                            
                            esp.DrawLinePlayer(clrLine, 2,
                                               Vec2(screenWidth / 2, screenHeight / 8),
                                               Vec2(x, top - screenHeight / 32));
                        }

                    }

                    //Start Function Grenade
                    for (int i = 0; i < response.GrenadeCount; i++) {
                        if (!isGrenadeWarning)
                            continue;
                        if (response.Grenade[i].Location.z != 1.0f) {
                            if (response.Grenade[i].type == 1) {
                                sprintf(extra, "Grenade (%0.0f m)",
                                        response.Grenade[i].Distance);
                                esp.DrawText(Color(255, 0, 0, 255), extra,
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y + 20), textsize);
                            } else if (response.Grenade[i].type == 2) {
                                sprintf(extra, "Molotov (%0.0f m)",
                                        response.Grenade[i].Distance);
                                esp.DrawText(Color(255, 169, 0, 255), extra,
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y + 20), textsize);
                            } else if (response.Grenade[i].type == 3) {
                                sprintf(extra, "Stun (%0.0f m)",
                                        response.Grenade[i].Distance);
                                esp.DrawText(Color(255, 255, 0, 255), extra,
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y + 20), textsize);
                            } else {
                                sprintf(extra, "Smoke (%0.0f m)",
                                        response.Grenade[i].Distance);
                                esp.DrawText(Color(0, 255, 0, 255), extra,
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y + 20), textsize);
                            }
                        }

                        esp.DrawEnemyCountC(Color(0, 100, 255),
                                            Vec2(screenWidth / 2 - screenHeight / 4.8,
                                                 screenHeight / 7.0),
                                            Vec2(screenWidth / 2 + screenHeight / 4.8,
                                                 screenHeight / 5.5));
                        esp.DrawText(Color().White(), "Warning : Throwable",
                                     Vec2(screenWidth / 2, screenHeight / 5.9), screenHeight / 35);
                        if (response.Grenade[i].Location.z != 1.0f) {
                            if (response.Grenade[i].type == 1)
                                esp.DrawText(Color(255, 0, 0, 255), "〇",
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y), textsize);
                            else if (response.Grenade[i].type == 2)
                                esp.DrawText(Color(255, 169, 0, 255), "〇",
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y), textsize);
                            else if (response.Grenade[i].type == 3)
                                esp.DrawText(Color(255, 255, 0, 255), "〇",
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y), textsize);
                            else
                                esp.DrawText(Color(0, 255, 0, 255), "〇",
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y), textsize);
                        }
                    } //End Function Grenade


                    //TODO ZONA DATA
                    for (int i = 0; i < response.ZoneCount; i++) {
                        if (response.Zones[i].Location.z != 1.0f) {
                            sprintf(extra, ("Rocket (%0.0f m)"), response.Zones[i].Distance);
                            esp.DrawText(Color(255, 0, 0, 255), extra,
                                         Vec2(response.Zones[i].Location.x,
                                              response.Zones[i].Location.y + 20), textsize);
                        }
                        esp.DrawText(Color(255, 0, 0, 255), "☄︎", Vec2(response.Zones[i].Location.x,
                                                                       response.Zones[i].Location.y),
                                     textsize);
                        esp.DrawEnemyCountC(Color(180, 0, 0),
                                            Vec2(screenWidth / 2 - screenHeight / 5,
                                                 screenHeight / 5.3),
                                            Vec2(screenWidth / 2 + screenHeight / 5,
                                                 screenHeight / 4.4));
                        esp.DrawText(Color().White(), "Warning : Red Zone",
                                     Vec2(screenWidth / 2, screenHeight / 4.6), screenHeight / 35);
                    } // End Function Zone
                }

                //TODO : Draw Vehicle
                float textsize=screenHeight/25;
                for (int i = 0; i < response.VehicleCount; i++) {
                    if (response.Vehicles[i].Location.z != 1.0f) {
                        esp.DrawVehicles(response.Vehicles[i].VehicleName,
                                         response.Vehicles[i].Distance,
                                         response.Vehicles[i].Health,
                                         response.Vehicles[i].Fuel,
                                         Vec2(response.Vehicles[i].Location.x,
                                              response.Vehicles[i].Location.y), screenHeight / textsize);
                    }
                } //End Function


                //TODO : Draw Items
                for (int i = 0; i < response.ItemsCount; i++) {
                    if (response.Items[i].Location.z != 1.0f) {
                        esp.DrawItems(response.Items[i].ItemName, response.Items[i].Distance,
                                      Vec2(response.Items[i].Location.x, response.Items[i].Location.y),
                                      screenHeight / 50);
                    }
                } //End Function

                //TODO : Aimbot FOV
                if (options.aimBullet == 0)//for Aimbot
                    esp.DrawCircle(Color(255,0,0), Vec2(screenWidth / 2, screenHeight / 2),
                                   options.aimingRange, 1.5);
   //         } //End Function
     //   }
  //  }
}

#endif // REPUBLIC_CHEAT_IMPORTANT_HACKS_H