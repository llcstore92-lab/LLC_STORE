/*
* ZERO HAX SINCE 2022
* Emaiil : redcodebusines@gmail.com
*/

#ifndef ZERO_COLORRANDOM_H
#define ZERO_COLORRANDOM_H

Color _clrID(int TeamID,float alpha){
		Color clrID;
		if (TeamID == 0) {
                clrID = Color(243, 0, 255, 135);
            } else if (TeamID == 1) {
                clrID = Color(243, 0, 255, 135);
            } else if (TeamID == 2) {
                clrID = Color(170, 0, 255, 135);
            } else if (TeamID == 3) {
                clrID = Color(243, 0, 255, 135);
            } else if (TeamID == 4) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 5) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 6) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 7) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 8) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 9) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 10) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 11) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 12) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 13) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 14) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 15) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 16) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 17) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 18) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 19) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 20) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 21) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 22) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 23) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 24) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 25) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 26) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 27) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 28) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 29) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 30) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 31) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 32) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 33) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 34) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 35) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 36) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 37) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 38) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 39) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 40) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 41) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 42) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 43) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 44) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 45) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 46) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 47) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 48) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 49) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 50) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 51) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 52) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 53) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 54) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 55) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 56) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 57) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 58) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 59) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 60) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 61) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 62) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 63) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 64) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 65) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 66) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 67) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 68) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 69) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 70) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 71) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 72) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 73) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 74) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 75) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 76) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 77) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 78) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 79) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 80) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 81) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 82) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 83) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 84) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 85) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 86) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 87) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 88) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 89) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 90) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 91) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 92) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 93) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 94) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 95) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 96) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 97) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 98) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 99) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 100) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 101) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 102) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 103) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 104) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 105) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 106) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 107) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 108) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 109) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 110) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 111) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 112) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 113) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 114) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 115) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 116) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 117) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 118) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 119) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 120) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 121) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 122) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 123) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 124) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 125) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 126) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 127) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 128) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 129) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 130) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 131) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 132) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 133) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 134) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 135) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 136) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 137) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 138) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 139) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 140) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 141) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 142) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 143) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 144) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 145) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 146) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 147) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 148) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 149) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 150) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 151) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 152) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 153) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 154) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 155) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 156) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 157) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 158) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 159) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 160) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 161) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 162) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 163) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 164) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 165) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 166) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 167) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 168) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 169) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 170) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 171) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 172) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 173) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 174) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 175) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 176) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 177) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 178) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 179) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 180) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 181) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 182) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 183) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 184) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 185) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 186) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 187) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 188) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 189) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 190) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 191) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 192) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 193) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 194) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 195) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 196) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 197) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 198) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 199) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 200) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 201) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 202) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 203) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 204) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 205) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 206) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 207) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 208) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 209) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 210) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 211) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 212) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 213) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 214) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 215) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 216) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 217) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 218) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 219) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 220) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 221) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 222) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 223) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 224) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 225) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 226) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 227) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 228) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 229) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 230) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 231) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 232) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 233) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 234) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 235) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 236) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 237) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 238) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 239) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 240) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 241) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 242) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 243) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 244) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 245) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 246) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 247) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 248) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 249) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 250) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 251) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 252) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 253) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 254) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 255) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 256) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 257) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 258) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 259) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 260) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 261) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 262) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 263) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 264) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 265) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 266) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 267) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 268) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 269) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 270) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 271) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 272) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 273) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 274) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 275) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 276) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 277) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 278) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 279) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 280) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 281) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 282) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 283) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 284) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 285) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 286) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 287) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 288) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 289) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 290) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 291) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 292) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 293) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 294) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 295) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 296) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 297) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 298) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 299) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 300) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 301) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 302) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 303) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 304) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 305) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 306) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 307) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 308) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 309) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 310) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 311) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 312) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 313) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 314) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 315) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 316) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 317) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 318) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 319) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 320) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 321) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 322) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 323) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 324) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 325) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 326) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 327) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 328) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 329) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 330) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 331) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 332) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 333) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 334) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 335) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 336) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 337) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 338) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 339) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 340) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 341) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 342) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 343) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 344) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 345) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 346) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 347) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 348) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 349) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 350) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 351) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 352) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 353) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 354) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 355) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 356) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 357) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 358) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 359) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 360) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 361) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 362) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 363) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 364) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 365) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 366) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 367) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 368) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 369) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 370) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 371) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 372) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 373) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 374) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 375) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 376) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 377) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 378) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 379) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 380) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 381) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 382) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 383) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 384) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 385) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 386) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 387) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 388) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 389) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 390) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 391) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 392) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 393) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 394) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 395) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 396) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 397) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 398) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 399) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 400) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 401) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 402) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 403) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 404) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 405) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 406) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 407) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 408) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 409) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 410) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 411) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 412) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 413) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 414) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 415) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 416) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 417) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 418) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 419) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 420) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 421) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 422) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 423) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 424) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 425) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 426) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 427) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 428) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 429) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 430) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 431) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 432) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 433) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 434) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 435) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 436) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 437) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 438) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 439) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 440) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 441) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 442) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 443) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 444) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 445) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 446) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 447) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 448) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 449) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 450) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 451) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 452) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 453) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 454) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 455) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 456) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 457) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 458) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 459) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 460) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 461) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 462) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 463) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 464) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 465) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 466) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 467) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 468) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 469) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 470) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 471) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 472) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 473) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 474) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 475) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 476) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 477) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 478) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 479) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 480) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 481) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 482) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 483) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 484) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 485) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 486) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 487) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 488) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 489) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 490) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 491) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 492) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 493) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 494) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 495) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 496) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 497) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 498) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 499) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 500) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 501) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 502) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 503) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 504) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 505) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 506) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 507) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 508) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 509) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 510) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 511) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 512) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 513) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 514) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 515) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 516) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 517) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 518) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 519) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 520) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 521) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 522) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 523) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 524) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 525) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 526) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 527) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 528) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 529) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 530) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 531) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 532) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 533) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 534) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 535) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 536) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 537) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 538) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 539) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 540) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 541) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 542) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 543) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 544) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 545) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 546) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 547) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 548) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 549) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 550) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 551) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 552) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 553) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 554) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 555) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 556) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 557) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 558) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 559) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 560) {

clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 561) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 562) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 563) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 564) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 565) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 566) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 567) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 568) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 569) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 570) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 571) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 572) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 573) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 574) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 575) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 576) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 577) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 578) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 579) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 580) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 581) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 582) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 583) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 584) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 585) {
                clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 586) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 587) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 588) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 589) {
                clrID = Color(153, 255, 255, 135);
            } else if (TeamID == 590) {
                clrID = Color(102, 255, 255, 135);
            } else if (TeamID == 591) {
                clrID = Color(255, 128, 0, 135);
            } else if (TeamID == 592) {
                clrID = Color(255, 0, 0, 135);
            } else if (TeamID == 593) {
                clrID = Color(0, 0, 255, 135);
            } else if (TeamID == 594) {
                clrID = Color(128, 255, 0, 135);
            } else if (TeamID == 595) {

clrID = Color(255, 0, 255, 135);
            } else if (TeamID == 596) {
                clrID = Color(128, 128, 128, 135);
            } else if (TeamID == 597) {
                clrID = Color(255, 255, 255, 135);
            } else if (TeamID == 598) {
                clrID = Color(102, 102, 255, 135);
            } else if (TeamID == 599) {
                clrID = Color(153, 255, 255, 135);
            } else {
                clrID = Color(255, 128, 0, 135);
            }
		return clrID;
	}

			
	Color TeamById(int TeamID,float alpha){
		Color _ColorTeamById;
		if (TeamID == 1)
			_ColorTeamById = Color(102,102,153, 200);
		if (TeamID == 2)
			_ColorTeamById = Color(162,107,152, 200);
	    if (TeamID == 3)
            _ColorTeamById = Color(108,164,81, 200);
        if (TeamID == 4)
            _ColorTeamById = Color(90,110,220, 200);
        if (TeamID == 5)
            _ColorTeamById = Color(164,162,195, 200);
        if (TeamID == 6)
            _ColorTeamById = Color(98,81,89, 200);
        if (TeamID == 7)
            _ColorTeamById = Color(26,255,26, 200);
        if (TeamID == 8)
            _ColorTeamById = Color(164,42,42, 200);
         if (TeamID == 9)
            _ColorTeamById = Color(84,155,120, 200);
        if (TeamID == 10)
            _ColorTeamById = Color(146,190,255, 200);
        if (TeamID == 11)
            _ColorTeamById = Color(80,157,183, 200);
        if (TeamID == 12)
            _ColorTeamById = Color(88,171,154, 200);  
		if (TeamID == 13)
			_ColorTeamById = Color(135,79,184, 200);  
		if (TeamID > 14)
			_ColorTeamById = Color(135,79,184, 200);  
		return _ColorTeamById;
	}

	Color TeamById2(int TeamID,float alpha){
		Color _ColorTeamById2;
		if (TeamID == 1)
			_ColorTeamById2 = Color(102,102,153, 255);
		if (TeamID == 2)
			_ColorTeamById2 = Color(162,107,152, 255);
	    if (TeamID == 3)
            _ColorTeamById2 = Color(108,164,81, 255);
        if (TeamID == 4)
            _ColorTeamById2 = Color(90,110,220, 255);
        if (TeamID == 5)
            _ColorTeamById2 = Color(164,162,195, 255);
        if (TeamID == 6)
            _ColorTeamById2 = Color(98,81,89, 255);
        if (TeamID == 7)
            _ColorTeamById2 = Color(26,255,26, 255);
        if (TeamID == 8)
            _ColorTeamById2 = Color(164,42,42, 255);
         if (TeamID == 9)
            _ColorTeamById2 = Color(84,155,120, 255);
        if (TeamID == 10)
            _ColorTeamById2 = Color(146,190,255, 255);
        if (TeamID == 11)
            _ColorTeamById2 = Color(80,157,183, 255);
        if (TeamID == 12)
            _ColorTeamById2 = Color(88,171,154, 255);  
		if (TeamID == 13)
			_ColorTeamById2 = Color(135,79,184, 255);  
		if (TeamID > 14)
			_ColorTeamById2 = Color(135,79,184, 255);  
		return _ColorTeamById2;
	}

	Color _clrID2(int TeamID,float alpha){
		Color clrID2;
		if (TeamID == 0) {
                clrID2 = Color(243, 0, 255, 135);
            } else if (TeamID == 1) {
                clrID2 = Color(243, 0, 255, 135);
            } else if (TeamID == 2) {
                clrID2 = Color(170, 0, 255, 135);
            } else if (TeamID == 3) {
                clrID2 = Color(243, 0, 255, 135);
            } else if (TeamID == 4) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 5) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 6) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 7) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 8) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 9) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 10) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 11) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 12) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 13) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 14) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 15) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 16) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 17) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 18) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 19) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 20) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 21) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 22) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 23) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 24) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 25) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 26) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 27) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 28) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 29) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 30) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 31) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 32) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 33) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 34) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 35) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 36) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 37) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 38) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 39) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 40) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 41) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 42) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 43) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 44) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 45) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 46) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 47) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 48) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 49) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 50) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 51) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 52) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 53) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 54) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 55) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 56) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 57) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 58) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 59) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 60) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 61) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 62) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 63) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 64) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 65) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 66) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 67) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 68) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 69) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 70) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 71) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 72) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 73) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 74) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 75) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 76) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 77) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 78) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 79) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 80) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 81) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 82) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 83) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 84) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 85) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 86) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 87) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 88) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 89) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 90) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 91) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 92) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 93) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 94) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 95) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 96) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 97) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 98) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 99) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 100) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 101) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 102) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 103) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 104) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 105) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 106) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 107) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 108) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 109) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 110) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 111) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 112) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 113) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 114) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 115) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 116) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 117) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 118) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 119) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 120) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 121) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 122) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 123) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 124) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 125) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 126) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 127) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 128) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 129) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 130) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 131) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 132) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 133) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 134) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 135) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 136) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 137) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 138) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 139) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 140) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 141) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 142) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 143) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 144) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 145) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 146) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 147) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 148) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 149) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 150) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 151) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 152) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 153) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 154) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 155) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 156) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 157) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 158) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 159) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 160) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 161) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 162) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 163) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 164) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 165) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 166) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 167) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 168) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 169) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 170) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 171) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 172) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 173) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 174) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 175) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 176) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 177) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 178) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 179) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 180) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 181) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 182) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 183) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 184) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 185) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 186) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 187) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 188) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 189) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 190) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 191) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 192) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 193) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 194) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 195) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 196) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 197) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 198) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 199) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 200) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 201) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 202) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 203) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 204) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 205) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 206) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 207) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 208) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 209) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 210) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 211) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 212) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 213) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 214) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 215) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 216) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 217) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 218) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 219) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 220) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 221) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 222) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 223) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 224) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 225) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 226) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 227) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 228) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 229) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 230) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 231) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 232) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 233) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 234) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 235) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 236) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 237) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 238) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 239) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 240) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 241) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 242) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 243) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 244) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 245) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 246) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 247) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 248) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 249) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 250) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 251) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 252) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 253) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 254) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 255) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 256) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 257) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 258) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 259) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 260) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 261) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 262) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 263) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 264) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 265) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 266) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 267) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 268) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 269) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 270) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 271) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 272) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 273) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 274) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 275) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 276) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 277) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 278) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 279) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 280) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 281) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 282) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 283) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 284) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 285) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 286) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 287) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 288) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 289) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 290) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 291) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 292) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 293) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 294) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 295) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 296) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 297) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 298) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 299) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 300) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 301) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 302) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 303) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 304) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 305) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 306) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 307) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 308) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 309) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 310) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 311) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 312) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 313) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 314) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 315) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 316) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 317) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 318) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 319) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 320) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 321) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 322) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 323) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 324) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 325) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 326) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 327) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 328) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 329) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 330) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 331) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 332) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 333) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 334) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 335) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 336) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 337) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 338) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 339) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 340) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 341) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 342) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 343) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 344) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 345) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 346) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 347) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 348) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 349) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 350) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 351) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 352) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 353) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 354) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 355) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 356) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 357) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 358) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 359) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 360) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 361) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 362) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 363) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 364) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 365) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 366) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 367) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 368) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 369) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 370) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 371) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 372) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 373) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 374) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 375) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 376) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 377) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 378) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 379) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 380) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 381) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 382) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 383) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 384) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 385) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 386) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 387) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 388) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 389) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 390) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 391) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 392) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 393) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 394) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 395) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 396) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 397) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 398) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 399) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 400) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 401) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 402) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 403) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 404) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 405) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 406) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 407) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 408) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 409) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 410) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 411) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 412) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 413) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 414) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 415) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 416) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 417) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 418) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 419) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 420) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 421) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 422) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 423) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 424) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 425) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 426) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 427) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 428) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 429) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 430) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 431) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 432) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 433) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 434) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 435) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 436) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 437) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 438) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 439) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 440) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 441) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 442) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 443) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 444) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 445) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 446) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 447) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 448) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 449) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 450) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 451) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 452) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 453) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 454) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 455) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 456) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 457) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 458) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 459) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 460) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 461) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 462) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 463) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 464) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 465) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 466) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 467) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 468) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 469) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 470) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 471) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 472) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 473) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 474) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 475) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 476) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 477) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 478) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 479) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 480) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 481) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 482) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 483) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 484) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 485) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 486) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 487) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 488) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 489) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 490) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 491) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 492) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 493) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 494) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 495) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 496) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 497) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 498) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 499) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 500) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 501) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 502) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 503) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 504) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 505) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 506) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 507) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 508) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 509) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 510) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 511) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 512) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 513) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 514) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 515) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 516) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 517) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 518) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 519) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 520) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 521) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 522) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 523) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 524) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 525) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 526) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 527) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 528) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 529) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 530) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 531) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 532) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 533) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 534) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 535) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 536) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 537) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 538) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 539) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 540) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 541) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 542) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 543) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 544) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 545) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 546) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 547) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 548) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 549) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 550) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 551) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 552) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 553) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 554) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 555) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 556) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 557) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 558) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 559) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 560) {

clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 561) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 562) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 563) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 564) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 565) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 566) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 567) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 568) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 569) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 570) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 571) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 572) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 573) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 574) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 575) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 576) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 577) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 578) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 579) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 580) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 581) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 582) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 583) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 584) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 585) {
                clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 586) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 587) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 588) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 589) {
                clrID2 = Color(153, 255, 255, 135);
            } else if (TeamID == 590) {
                clrID2 = Color(102, 255, 255, 135);
            } else if (TeamID == 591) {
                clrID2 = Color(255, 128, 0, 135);
            } else if (TeamID == 592) {
                clrID2 = Color(255, 0, 0, 135);
            } else if (TeamID == 593) {
                clrID2 = Color(0, 0, 255, 135);
            } else if (TeamID == 594) {
                clrID2 = Color(128, 255, 0, 135);
            } else if (TeamID == 595) {

clrID2 = Color(255, 0, 255, 135);
            } else if (TeamID == 596) {
                clrID2 = Color(128, 128, 128, 135);
            } else if (TeamID == 597) {
                clrID2 = Color(255, 255, 255, 135);
            } else if (TeamID == 598) {
                clrID2 = Color(102, 102, 255, 135);
            } else if (TeamID == 599) {
                clrID2 = Color(153, 255, 255, 135);
            } else {
                clrID2 = Color(255, 128, 0, 135);
            }
		return clrID2;
	}
	
    // Color Random Distance Drawing
    Color colorByDistance(int distance, float alpha){
        Color _colorByDistance;
        if (distance < 450)
            _colorByDistance = Color(102,102,153, alpha);
        if (distance < 200)
            _colorByDistance = Color(255,255,0, alpha);
        if (distance < 120)
            _colorByDistance = Color(255,0,102, alpha);
        if (distance < 90)
            _colorByDistance = Color(51,133,255, alpha);
        if (distance < 80)
            _colorByDistance = Color(0,0,102, alpha);
        if (distance < 70)
            _colorByDistance = Color(255,133,51, alpha);
        if (distance < 60)
            _colorByDistance = Color(26,255,26, alpha);
        if (distance < 50)
            _colorByDistance = Color(255,0,0, alpha);
         if (distance < 40)
            _colorByDistance = Color(0,255,0, alpha);
        if (distance < 30)
            _colorByDistance = Color(255,255,51, alpha);
        if (distance < 20)
            _colorByDistance = Color(0,0,255, alpha);
        if (distance < 10)
            _colorByDistance = Color(255,77,77, alpha);  
        return _colorByDistance;
    }
    
   
#endif //ZERO_COLOR_RANDOM_H
